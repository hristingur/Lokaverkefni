<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="takkar.css">
</head>
<body>
    <ul class="valmynd">
        <ul id="navigationMenu">
    <li class="home">
        <a class="home" href="#">
            <span>Home</span>
        </a>
    </li>
    
    <li>
        <a class="about" href="#">
            <span>About</span>
        </a>
    </li>
    
    <li>
         <a class="contact" href="contact.html">
            <span>Contact Us</span>
         </a>
    </li>
    
  
</ul>
    </ul>
</body>
</html>

